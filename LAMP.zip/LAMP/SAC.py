# -*- coding: utf-8 -*-
"""
Program name: SAC - Soil Apparent Cohesion

Created on Fri Jun  3 14:21:52 2022
@authors: Stefania Viaggio, Estelle Stefanini, Rossella Bovolenta, Bianca Federici
Estelle was student at the National School of Geographic Sciences (ENSG - France); she wrote the initial version of the codes in python during her internship in the Geomatic Lab at the University of Genova (UniGe - Italy)
Stefania was PhD candidate in the Geomatic Lab at the University of Genova (UniGe - It); she define the procedure and improved the codes.
They both worked under the supervision of Profs Rossella Bovolenta and Bianca Federici, at UniGe.

Copyright (C) 2022 Viaggio, Stefanini, Bovolenta, Federici

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program.  If not, see https://www.gnu.org/licenses/.

SAC.py -> Considering rain-triggered shallow landslides, the stability can be markedly influenced by the propagation of the saturation front inside the unsaturated zone. Soil shear strength varies in the vadose zone depending on the type of soil and the variations of soil moisture. Monitoring of the unsaturated zone can be done by measuring volumetric water content using low-cost instrumentation (i.e. capacitive sensors) that are easy to manage and provide data in near-real time. For a proper soil moisture assessment a laboratory soil-specific calibration of the sensors is recommended. Knowing the soil water content, the suction parameter can be estimated by a Water Retention Curve (WRC), and consequently the soil shear strength in unsaturated conditions is evaluated. The automatic procedure developed in GIS environment, named assessment of Soil Apparent Cohesion (SAC), here described, allows the estimate of the soil shear strength starting from soil moisture monitoring data (from sensor networks or satellite-derived map). SAC results can be integrated into existing models for landslide susceptibility assessment and also for the emergency management.

If you need to contact us: stefaniaviaggio at gmail.com, rossella.bovolenta at unige.it, bianca.federici at unige.it
"""

from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterNumber
from qgis.core import QgsProcessingParameterMapLayer
from qgis.core import QgsProcessingParameterFolderDestination
from qgis.core import QgsProcessingParameterEnum
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsVectorLayer, QgsVectorLayerUtils, QgsProcessingUtils, QgsMapLayer
import processing
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches



class SAC(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        #Definition of the parameters
        self.addParameter(QgsProcessingParameterEnum('type_input','Type of input data', options = ['raw vector data','calibrated vector data','VWC map','calibrated VWC map'], allowMultiple = False, defaultValue=None))
        self.addParameter(QgsProcessingParameterMapLayer('Data', 'Input data',defaultValue=None))
        self.addParameter(QgsProcessingParameterNumber('a', 'a', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=10000, defaultValue=276.5))
        self.addParameter(QgsProcessingParameterNumber('b', 'b', type=QgsProcessingParameterNumber.Double, minValue=-1000, maxValue=10000, defaultValue=-87.8))
        self.addParameter(QgsProcessingParameterNumber('Vin', 'Vin', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=10000, defaultValue=3.0))
        self.addParameter(QgsProcessingParameterNumber('Gs', '\n\nSpecific gravity of soil grains (Gs)', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=10000, defaultValue=2.6))
        self.addParameter(QgsProcessingParameterNumber('C', 'Carbon content (C)', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=100, defaultValue=3.0))
        self.addParameter(QgsProcessingParameterNumber('Sand', 'Sand fraction (Sand)', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=100, defaultValue=47.9))
        self.addParameter(QgsProcessingParameterNumber('Clay', 'Clay fraction (Clay)', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=100, defaultValue=29.0))
        self.addParameter(QgsProcessingParameterNumber('tan_phi', 'Tangent of the effective angle of shearing resistance for an unsaturated soil (tan(φ))', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=1, defaultValue=0.522))
        self.addParameter(QgsProcessingParameterNumber('teta_max', 'Highest volumetric water content (θmax)', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=10000, defaultValue=0.478))
        self.addParameter(QgsProcessingParameterFolderDestination('Output_Folder','\n\nFolder for dowload all the results'))
  
    
    def processAlgorithm(self, parameters, context, model_feedback):
        
        feedback = QgsProcessingMultiStepFeedback(1, model_feedback)
        results = {}
        outputs = {}
        
        folder = QgsProcessingUtils.tempFolder()
    
            
        
        ##Calculation of constants
        wmax = parameters['teta_max']/((1-parameters['teta_max'])*parameters['Gs'])
        rhod = ((1000*parameters['Gs'])/(1+wmax*parameters['Gs']))/1000
        alpha = np.exp(-2.486 + 0.025*parameters['Sand'] - 0.351*parameters['C'] - 2.617*rhod - 0.023*parameters['Clay'])
        n = np.exp(0.053 + 0.009*parameters['Sand'] - 0.013*parameters['Clay'] - 0.00015*(parameters['Sand']**2))
        teta_r = 0.015 + 0.005*parameters['Clay'] + 0.014*parameters['C']
        teta_s = 0.81 - 0.283*rhod + 0.001*parameters['Clay']
        
        s = [0.001, 0.05, 0.075, 0.1, 0.25, 0.5, 0.75, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5] + [5*i for i in range(1,20000)]
       
        results['wmax']=wmax
        results['ρd']=rhod
        results['α']=alpha
        results['n']=n
        results['θr']=teta_r
        results['θs']=teta_s
        
        
        #Writting of the .txt file which contain constants
        file = open(parameters['Output_Folder'].replace('/','\\')+'\\WRC_params.txt', "w") 
        file.write('wmax = '+str(wmax)+'\n'+'ρd = '+str(rhod)+'\n'+'α = '+str(alpha)+'\n'+'n = '+str(n)+'\n'+'θr = '+str(teta_r)+'\n'+'θs = '+str(teta_s)) 
        file.close()
        
        if parameters['type_input']==0:     #if input is raw vector data 
            #Recovery of the data, the list of fields names and the values of z 
            data = self.parameterAsLayer(parameters, 'Data', context)
            fields = data.fields().names()
            z_value = QgsVectorLayerUtils.getValues(data, 'z_ground')[0]
            z_value = list(set(z_value))

           
            
            input_0 = parameters['Data']
            for i in range(len(fields)-4):      # for each date
                cal = 'Cal_' + fields[i+4][0:6]
    
    
                #Calibration of the data
                formule ='('+str(parameters['a'])+'*"'+ fields[i+4]+ '"/' +str(parameters['Vin'])+'+'+str(parameters['b'])+')/100'
                formule_suite = 'if('+formule+'<='+str(teta_r)+','+str(teta_r+0.001)+','+formule+')'
                alg_params = {
                    'INPUT': input_0,
                    'FIELD_NAME': cal,
                    'FIELD_TYPE': 0,  # Flottant
                    'FIELD_LENGTH': 10,
                    'FIELD_PRECISION': 3,
                    'FORMULA': formule_suite,
                    'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
                }
                outputs[cal] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results[cal] = outputs[cal]['OUTPUT']
                
                #Calculation of s_eff
                input_0 = outputs[cal]['OUTPUT']
                
                s_eff = 'seff_'+ fields[i+4][0:6]
                formule = '("' + cal + '"-' + str(teta_r) + ')/(' + str(parameters['teta_max']) + '-' + str(teta_r) + ')'
                alg_params = {
                    'INPUT': input_0,
                    'FIELD_NAME': s_eff,
                    'FIELD_TYPE': 0,  # Flottant
                    'FIELD_LENGTH': 10,
                    'FIELD_PRECISION': 3,
                    'FORMULA': formule,
                    'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT  
                }
                outputs[s_eff] = processing.run('native:fieldcalculator', alg_params,  context=context, feedback=feedback, is_child_algorithm=True)
                results[s_eff] = outputs[s_eff]['OUTPUT']
                
                
                #Calculation of the suction
                input_0 =  outputs[s_eff]['OUTPUT']
                
                suc = 's_' + fields[i+4][0:6]
                formule = '(10/' + str(alpha) + '*10^(-2))*(((' + str(teta_s) + '-"' + cal + '")/("' + cal + '"-' + str(teta_r) + '))^(1/' + str(n) + '))'
                alg_params = {
                    'INPUT': input_0,
                    'FIELD_NAME': suc,
                    'FIELD_TYPE': 0,  # Flottant
                    'FIELD_LENGTH': 10,
                    'FIELD_PRECISION': 3,
                    'FORMULA': formule,
                    'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT  
                }
                outputs[suc] = processing.run('native:fieldcalculator', alg_params,  context=context, feedback=feedback, is_child_algorithm=True)
                results[suc] = outputs[suc]['OUTPUT']
                
                
                #Calculation of the cohesion
                input_0 =  outputs[suc]['OUTPUT']
                
            
                if i != len(fields)-5:      #if not the last date save in temporary file
                    outname = folder.replace('/','\\')+'\\deltaC' +str(i)+ '.shp'
                else :                      #else save in the output folder
                    outname = parameters['Output_Folder']+'\\Results.shp'
                dC ='dC_' +  fields[i+4][0:6]
                formule = '"' + suc + '"*"' + s_eff + '"*' + str(parameters['tan_phi'])
                alg_params = {
                    'INPUT': input_0,
                    'FIELD_NAME': dC,
                    'FIELD_TYPE': 0,  # Float
                    'FIELD_LENGTH': 10,
                    'FIELD_PRECISION': 3,
                    'FORMULA': formule,
                    'OUTPUT':outname,
                }
                outputs[dC] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results[dC] = outputs[dC]['OUTPUT']
                input_0 =  outputs[dC]['OUTPUT']       
                
                
                #Export the results in a spreadsheet
                alg_params = {
                    'FORMATTED_VALUES': False,
                    'LAYERS': outputs[dC]['OUTPUT'],
                    'OVERWRITE': True,
                    'USE_ALIAS': False,
                    'OUTPUT': parameters['Output_Folder']+'\\table.csv'
                }
                outputs['tableur'] = processing.run('native:exporttospreadsheet', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            

                #for each z ground
                for z in z_value:
                    
                    #Selection of the attributes with the same value of z
                    selected = 'select_'+str(z)+'_'+fields[i+4]
                    alg_params = {
                        'INPUT': input_0,
                        'FIELD': 'z_ground',
                        'METHOD': 0,  # New selection
                        'OPERATOR': 0,  # equal to
                        'VALUE': z
                    }
                    outputs[selected] = processing.run('qgis:selectbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    
                    #Saving selected features in a temporary file
                    extracted = str(z)+'_'+fields[i+4]
                    alg_params = {
                        'INPUT': input_0,
                        'OUTPUT':folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp'
                    }
                    outputs[extracted] = processing.run('native:saveselectedfeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[extracted]= outputs[extracted]['OUTPUT']
                    

                    
                    #Interpolation of the VWC with raw data between the selected features  
                    field_number = i+4
                    int_name =  'VWC_raw_'+str(z)+'_'+fields[i+4]
                    rect = QgsVectorLayer.extent(data)
                    extent=str(rect.xMinimum())+','+str(rect.xMaximum())+','+str(rect.yMinimum())+','+str(rect.yMaximum())+' ['+str(QgsVectorLayer.sourceCrs(data))[-10:-1]+']'
                    int_data ='{}::~::{}::~::{}::~::{}'.format(folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp', '0', str(field_number), '0')
                    out_name = parameters['Output_Folder']+'\\'+'VWC_raw___'+str(z)+'___'+fields[i+4].replace('/','-')+'.tif'
                    alg_params = { 
                        'EXTENT' : extent, 
                        'INTERPOLATION_DATA' : int_data, 
                        'METHOD' : 0, 
                        'OUTPUT' : out_name, 
                        'PIXEL_SIZE' : 5 
                    }
                    outputs[int_name] = processing.run('qgis:tininterpolation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[int_name] = outputs[int_name]['OUTPUT']
                    
                    #Interpolation of the VWC with calibrated data between the selected features  
                    field_number = len(fields)+4*i
                    int_name =  'VWC_cal_'+str(z)+'_'+fields[i+4]
                    rect = QgsVectorLayer.extent(data)
                    extent=str(rect.xMinimum())+','+str(rect.xMaximum())+','+str(rect.yMinimum())+','+str(rect.yMaximum())+' ['+str(QgsVectorLayer.sourceCrs(data))[-10:-1]+']'
                    int_data ='{}::~::{}::~::{}::~::{}'.format(folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp', '0', str(field_number), '0')
                    out_name = parameters['Output_Folder']+'\\'+'VWC_cal___'+str(z)+'___'+fields[i+4].replace('/','-')+'.tif'
                    alg_params = { 
                        'EXTENT' : extent, 
                        'INTERPOLATION_DATA' : int_data, 
                        'METHOD' : 0, 
                        'OUTPUT' : out_name, 
                        'PIXEL_SIZE' : 5 
                    }
                    outputs[int_name] = processing.run('qgis:tininterpolation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[int_name] = outputs[int_name]['OUTPUT']
                    
                    
                    #Interpolation of the suction between the selected features  
                    field_number = len(fields)+(i+1)*4-2
                    int_name =  'Inter_'+str(z)+'_'+fields[i+4]
                    rect = QgsVectorLayer.extent(data)
                    extent=str(rect.xMinimum())+','+str(rect.xMaximum())+','+str(rect.yMinimum())+','+str(rect.yMaximum())+' ['+str(QgsVectorLayer.sourceCrs(data))[-10:-1]+']'
                    int_data ='{}::~::{}::~::{}::~::{}'.format(folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp', '0', str(field_number), '0')
                    out_name = parameters['Output_Folder']+'\\'+'Suction___'+str(z)+'___'+fields[i+4].replace('/','-')+'.tif'
                    alg_params = { 
                        'EXTENT' : extent, 
                        'INTERPOLATION_DATA' : int_data, 
                        'METHOD' : 0, 
                        'OUTPUT' : out_name, 
                        'PIXEL_SIZE' : 5 
                    }
                    outputs[int_name] = processing.run('qgis:tininterpolation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[int_name] = outputs[int_name]['OUTPUT']
                    
                    
                    #Interpolation of the cohesion between the selected features  
                    field_number = len(fields)+(i+1)*4-1
                    int_name =  'Cohesion_'+str(z)+'_'+fields[i+4]
                    rect = QgsVectorLayer.extent(data)
                    extent=str(rect.xMinimum())+','+str(rect.xMaximum())+','+str(rect.yMinimum())+','+str(rect.yMaximum())+' ['+str(QgsVectorLayer.sourceCrs(data))[-10:-1]+']'
                    int_data ='{}::~::{}::~::{}::~::{}'.format(folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp', '0', str(field_number), '0')
                    out_name = parameters['Output_Folder']+'\\'+'Cohesion___'+str(z)+'___'+fields[i+4].replace('/','-')+'.tif'
                    alg_params = { 
                        'EXTENT' : extent, 
                        'INTERPOLATION_DATA' : int_data, 
                        'METHOD' : 0, 
                        'OUTPUT' : out_name, 
                        'PIXEL_SIZE' : 5 
                    }
                    outputs[int_name] = processing.run('qgis:tininterpolation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[int_name] = outputs[int_name]['OUTPUT']
                    
        
        
        
        if parameters['type_input']==1:     #if type input is calibrated data
        
            #Recovery of the data, the list of fields names and the values of z 
            data = self.parameterAsLayer(parameters, 'Data', context)
            fields = data.fields().names()
            z_value = QgsVectorLayerUtils.getValues(data, 'z_ground')[0]
            z_value = list(set(z_value))
            
    
            
           
            
            input_0 = parameters['Data']
            for i in range(len(fields)-4):      # for each date
            
                #Calculation of s_eff
                s_eff = 'seff_'+ fields[i+4][0:6]
                formule = '("' + fields[i+4] + '"-' + str(teta_r) + ')/(' + str(parameters['teta_max']) + '-' + str(teta_r) + ')'
                alg_params = {
                    'INPUT': input_0,
                    'FIELD_NAME': s_eff,
                    'FIELD_TYPE': 0,  # Flottant
                    'FIELD_LENGTH': 10,
                    'FIELD_PRECISION': 3,
                    'FORMULA': formule,
                    'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT  
                }
                outputs[s_eff] = processing.run('native:fieldcalculator', alg_params,  context=context, feedback=feedback, is_child_algorithm=True)
                results[s_eff] = outputs[s_eff]['OUTPUT']
                
                #Calculation of the suction
                input_0 =  outputs[s_eff]['OUTPUT']
                
                suc = 's_'+fields[i+4][0:6]
                formule = '(10/' + str(alpha) + '*10^(-2))*(((' + str(teta_s) + '-"' + fields[i+4] + '")/("' + fields[i+4] + '"-' + str(teta_r) + '))^(1/' + str(n) + '))'
                alg_params = {
                    'INPUT': input_0,
                    'FIELD_NAME': suc,
                    'FIELD_TYPE': 0,  # Float
                    'FIELD_LENGTH': 10,
                    'FIELD_PRECISION': 3,
                    'FORMULA': formule,
                    'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT  
                }
                outputs[suc] = processing.run('native:fieldcalculator', alg_params,  context=context, feedback=feedback, is_child_algorithm=True)
                results[suc] = outputs[suc]['OUTPUT']
                
                
                #Calculation of the cohesion
                input_0 =  outputs[suc]['OUTPUT']
                
                
                if i != len(fields)-5:      #if not the last date save in temporary file
                    outname = folder.replace('/','\\')+'\\deltaC' +str(i)+ '.shp'
                else :                      #else save in the output folder
                    outname = parameters['Output_Folder']+'\\Results.shp'
                dC = 'dC_'+fields[i+4][0:6]
                formule = '"' + suc + '"*"' + s_eff + '"*' + str(parameters['tan_phi'])
                alg_params = {
                    'INPUT': input_0,
                    'FIELD_NAME': dC,
                    'FIELD_TYPE': 0,  # Flottant
                    'FIELD_LENGTH': 10,
                    'FIELD_PRECISION': 3,
                    'FORMULA': formule,
                    'OUTPUT':outname,
                }
                outputs[dC] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results[dC] = outputs[dC]['OUTPUT']
                input_0 =  outputs[dC]['OUTPUT']   
                
                
                #Export the results in a spreadsheet
                alg_params = {
                    'FORMATTED_VALUES': False,
                    'LAYERS': outputs[dC]['OUTPUT'],
                    'OVERWRITE': True,
                    'USE_ALIAS': False,
                    'OUTPUT': parameters['Output_Folder']+'\\table.csv'
                }
                outputs['tableur'] = processing.run('native:exporttospreadsheet', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

                
                for z in z_value:       #for each value oh z ground
                
                    #Selection of the attributes with the same value of z
                    selected = 'select_'+str(z)+'_'+fields[i+4]
                    alg_params = {
                        'INPUT': input_0,
                        'FIELD': 'z_ground',
                        'METHOD': 0,  # New selection
                        'OPERATOR': 0,  # equal to
                        'VALUE': z
                    }
                    outputs[selected] = processing.run('qgis:selectbyattribute', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    
                    #Saving selected features in a temporary file
                    extracted = str(z)+'_'+fields[i+4]
                    alg_params = {
                        'INPUT': input_0,
                        'OUTPUT':folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp'
                    }
                    outputs[extracted] = processing.run('native:saveselectedfeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[extracted]= outputs[extracted]['OUTPUT']
                    
                    #Interpolation of the VWC with calibrated data between the selected features  
                    field_number = i+4
                    int_name =  'VWC_cal_'+str(z)+'_'+fields[i+4]
                    rect = QgsVectorLayer.extent(data)
                    extent=str(rect.xMinimum())+','+str(rect.xMaximum())+','+str(rect.yMinimum())+','+str(rect.yMaximum())+' ['+str(QgsVectorLayer.sourceCrs(data))[-10:-1]+']'
                    int_data ='{}::~::{}::~::{}::~::{}'.format(folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp', '0', str(field_number), '0')
                    out_name = parameters['Output_Folder']+'\\'+'VWC_cal___'+str(z)+'___'+fields[i+4].replace('/','-')+'.tif'
                    alg_params = { 
                        'EXTENT' : extent, 
                        'INTERPOLATION_DATA' : int_data, 
                        'METHOD' : 0, 
                        'OUTPUT' : out_name, 
                        'PIXEL_SIZE' : 5 
                    }
                    outputs[int_name] = processing.run('qgis:tininterpolation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[int_name] = outputs[int_name]['OUTPUT']
                    
                    
                    #Interpolation of the suction between the selected features  
                    field_number = len(fields)+(i+1)*3-2
                    int_name =  'Inter_'+str(z)+'_'+fields[i+4]
                    rect = QgsVectorLayer.extent(data)
                    extent=str(rect.xMinimum())+','+str(rect.xMaximum())+','+str(rect.yMinimum())+','+str(rect.yMaximum())+' ['+str(QgsVectorLayer.sourceCrs(data))[-10:-1]+']'
                    int_data ='{}::~::{}::~::{}::~::{}'.format(folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp', '0', str(field_number), '0')
                    out_name = parameters['Output_Folder']+'\\'+'Suction___'+str(z)+'___'+fields[i+4].replace('/','-')+'.tif'
                    alg_params = { 
                        'EXTENT' : extent, 
                        'INTERPOLATION_DATA' : int_data, 
                        'METHOD' : 0, 
                        'OUTPUT' : out_name, 
                        'PIXEL_SIZE' : 5 
                    }
                    outputs[int_name] = processing.run('qgis:tininterpolation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[int_name] = outputs[int_name]['OUTPUT']
                    
                    
                    #Interpolation of the cohesion between the selected features  
                    field_number = len(fields)+(i+1)*3-1
                    int_name = fields[i+4] + '__Inter_'+str(z)
                    rect = QgsVectorLayer.extent(data)
                    extent=str(rect.xMinimum())+','+str(rect.xMaximum())+','+str(rect.yMinimum())+','+str(rect.yMaximum())+' ['+str(QgsVectorLayer.sourceCrs(data))[-10:-1]+']'
                    int_data ='{}::~::{}::~::{}::~::{}'.format(folder.replace('/','\\')+'\\'+fields[i+4].replace('/','-')+'__Extracted_'+str(z)+'.shp', '0', str(field_number), '0')
                    out_name = parameters['Output_Folder']+'\\'+'Cohesion___'+str(z)+'___'+fields[i+4].replace('/','-')+'.tif'
                    alg_params = { 
                        'EXTENT' : extent, 
                        'INTERPOLATION_DATA' : int_data, 
                        'METHOD' : 0, 
                        'OUTPUT' : out_name, 
                        'PIXEL_SIZE' : 5 
                    }
                    outputs[int_name] = processing.run('qgis:tininterpolation', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                    results[int_name] = outputs[int_name]['OUTPUT']
                    

                    
    
        if parameters['type_input']==2:     #if type inpur is a calibrated VWC map
            
        
            #Recovery of the map
            data = self.parameterAsLayer(parameters, 'Data', context)
            
            
            #Calibration of the data
            formule = '('+str(parameters['a'])+'*"'+ data.name()+ '@1"/'+str(parameters['Vin'])+'+'+str(parameters['b'])+')/100'
            alg_params = {
                'EXPRESSION':formule,
                'LAYERS':[parameters['Data']],
                'CELLSIZE':0,
                'EXTENT':None,
                'CRS':None,
                'OUTPUT':QgsProcessing.TEMPORARY_OUTPUT
            }
            outputs['Calibration']=processing.run("qgis:rastercalculator", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Calibration']=outputs['Calibration']['OUTPUT']
            
            
            #Calculation of s_eff
            cal = QgsProcessingUtils.mapLayerFromString(outputs['Calibration']['OUTPUT'], context)
            formule = '("' +QgsMapLayer.name(cal) + '@1"-' + str(teta_r) + ')/(' + str(parameters['teta_max']) + '-' + str(teta_r) + ')'
            alg_params = {
                'EXPRESSION':formule,
                'LAYERS':[parameters['Data'],cal],
                'CELLSIZE':0,
                'EXTENT':None,
                'CRS':None,
                'OUTPUT': folder.replace('/','\\') + '\\s_eff.tif'
            }
            outputs['s_eff']=processing.run("qgis:rastercalculator", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['s_eff']=outputs['s_eff']['OUTPUT']
            
            s_eff = QgsProcessingUtils.mapLayerFromString(outputs['s_eff']['OUTPUT'], context)
            
            
            #Calculation of the suction
            out_name = parameters['Output_Folder']+'\\'+data.name().replace('/','-')+'_Suction.tif'
            formule = '(10/' + str(alpha) + '*10^(-2))*(((' + str(teta_s) + '-"' + QgsMapLayer.name(cal) + '@1")/("' +QgsMapLayer.name(cal) + '@1"-' + str(teta_r) + '))^(1/' + str(n) + '))'
            alg_params = {
                'EXPRESSION':formule,
                'LAYERS':[parameters['Data'],cal],
                'CELLSIZE':0,
                'EXTENT':None,
                'CRS':None,
                'OUTPUT':out_name
            }
            outputs['suc']=processing.run("qgis:rastercalculator", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['suc']=outputs['suc']['OUTPUT']
            
            
            suc = QgsProcessingUtils.mapLayerFromString(outputs['suc']['OUTPUT'], context)
            
            #Calculation of the cohesion
            out_name = parameters['Output_Folder']+'\\'+data.name().replace('/','-')+'__Inter.tif'
            formule = '"'+  QgsMapLayer.name(suc)+'@1"*"'+ QgsMapLayer.name(s_eff)+'@1"*'+str(parameters['tan_phi'])
            alg_params = {
                'EXPRESSION':formule,
                'LAYERS':[parameters['Data'],cal,suc,s_eff],
                'CELLSIZE':0,
                'EXTENT':None,
                'CRS':None,
                'OUTPUT':out_name
            }
            outputs['Delta_C']=processing.run("qgis:rastercalculator", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Delta_C']=outputs['Delta_C']             

    
        if parameters['type_input']==2:     #if type inpur is a VWC map
            
        
            #Recovery of the map
            data = self.parameterAsLayer(parameters, 'Data', context)
            
            
            
            #Calculation of s_eff
            cal = QgsProcessingUtils.mapLayerFromString(outputs['Calibration']['OUTPUT'], context)
            formule = '("' +data.name() + '@1"-' + str(teta_r) + ')/(' + str(parameters['teta_max']) + '-' + str(teta_r) + ')'
            alg_params = {
                'EXPRESSION':formule,
                'LAYERS':[parameters['Data']],
                'CELLSIZE':0,
                'EXTENT':None,
                'CRS':None,
                'OUTPUT': folder.replace('/','\\') + '\\s_eff.tif'
            }
            outputs['s_eff']=processing.run("qgis:rastercalculator", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['s_eff']=outputs['s_eff']['OUTPUT']
            
            s_eff = QgsProcessingUtils.mapLayerFromString(outputs['s_eff']['OUTPUT'], context)
            
            
            #Calculation of the suction
            out_name = parameters['Output_Folder']+'\\'+data.name().replace('/','-')+'_Suction.tif'
            formule = '(10/' + str(alpha) + '*10^(-2))*(((' + str(teta_s) + '-"' + data.name() + '@1")/("' +data.name() + '@1"-' + str(teta_r) + '))^(1/' + str(n) + '))'
            alg_params = {
                'EXPRESSION':formule,
                'LAYERS':[parameters['Data']],
                'CELLSIZE':0,
                'EXTENT':None,
                'CRS':None,
                'OUTPUT':out_name
            }
            outputs['suc']=processing.run("qgis:rastercalculator", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['suc']=outputs['suc']['OUTPUT']
            
            
            suc = QgsProcessingUtils.mapLayerFromString(outputs['suc']['OUTPUT'], context)
            
            #Calculation of the cohesion
            out_name = parameters['Output_Folder']+'\\'+data.name().replace('/','-')+'__Inter.tif'
            formule = '"'+  QgsMapLayer.name(suc)+'@1"*"'+ QgsMapLayer.name(s_eff)+'@1"*'+str(parameters['tan_phi'])
            alg_params = {
                'EXPRESSION':formule,
                'LAYERS':[parameters['Data'],suc,s_eff],
                'CELLSIZE':0,
                'EXTENT':None,
                'CRS':None,
                'OUTPUT':out_name
            }
            outputs['Delta_C']=processing.run("qgis:rastercalculator", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Delta_C']=outputs['Delta_C']     
            
                    
        # Function to calculate teta for a list of values s given
        def calc_teta(teta_r, teta_s, alpha, n, s):
            teta = []
            for i in s:
                teta.append(teta_r + (teta_s - teta_r)/(1 + (alpha*i/10)**n))
            return teta
    
    
        # Drawing of the WRC
        plt.figure()
        plt.plot(s, calc_teta(teta_r, teta_s, alpha, n, s), 'b')
        plt.plot(s, [teta_r for i in range(len(s))], 'orange')
        plt.scatter(1, teta_s, color='black')
        plt.xscale("log")
        plt.axis([1,100000,0,0.5])
        plt.xlabel('log(s) [kPa]')
        plt.ylabel('θv [-]')
        black_patch = mpatches.Patch(color='black', label='θs')
        blue_patch = mpatches.Patch(color='blue', label='WRC')
        orange_patch = mpatches.Patch(color='orange', label='θr')
        plt.legend(handles=[black_patch, blue_patch, orange_patch])
        plt.savefig(parameters['Output_Folder']+'\\WRC.png')
        
        return results
            
    def name(self):
        return 'SAC'

    def displayName(self):
        return 'SAC'
    
    def tr(self, string):
        return QCoreApplication.translate('Processing', string)
    
    def shortHelpString(self):
        return self.tr("The script will give you the Soil Water Retention Curve (SWRC) and the unsaturated soil shear strength under partial saturation conditions.\n\nThe input data must be designed as follows:\n-Vector data .shp file with sensor name, coordinates (E and N), installation depth (named z_ground) and for the volumetric water content a number of columns corresponding to the number of days to be analysed, named with the daily date\n-Raster data can be Volumetric Water Countent maps\n\na and b are the values used to calibrate the raw data with the equation data_calibrated = a*raw_data/Vin + b")

    def createInstance(self):
        return SAC()
    
        