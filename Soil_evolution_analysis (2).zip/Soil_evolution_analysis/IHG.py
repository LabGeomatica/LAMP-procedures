# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterNumber
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProcessingParameterRasterLayer
from qgis.core import QgsProcessingParameterFolderDestination
from qgis.core import QgsProcessingParameterFile
from qgis.core import QgsProcessingParameterMultipleLayers
from qgis.core import QgsProcessingUtils
import processing
import pandas as pd



class IHG(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer('DTM', 'Digital Terrain Model (DTM)', defaultValue=None))
        self.addParameter(QgsProcessingParameterRasterLayer('falda', 'Water table', defaultValue=None))
        self.addParameter(QgsProcessingParameterRasterLayer('bedrock', 'Bedrock', defaultValue=None))
        self.addParameter(QgsProcessingParameterRasterLayer('CN', 'Curve Number Map (CN_II)', defaultValue=None))
        self.addParameter(QgsProcessingParameterNumber('Gamma', 'Weight of the soil per unit of volume (γ)', type=QgsProcessingParameterNumber.Double, minValue=-1000, maxValue=10000, defaultValue=20))
        self.addParameter(QgsProcessingParameterNumber('coes', 'Effective cohesion', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=10000, defaultValue=5))
        self.addParameter(QgsProcessingParameterNumber('tan_phi', 'Tangent of the angle of shear resistance (tan(φ))', type=QgsProcessingParameterNumber.Double, minValue=0, maxValue=1, defaultValue=0.32491969623))
        self.addParameter(QgsProcessingParameterRasterLayer('ks_carico', 'Hydraulic conductivity for rainy days (ks_charge)', defaultValue=None))
        self.addParameter(QgsProcessingParameterRasterLayer('ks_scarico', 'Hydraulic conductivity for days without rain (ks_discharge)', defaultValue=None))
        self.addParameter(QgsProcessingParameterRasterLayer('neff', 'Effective porosity (neff)', defaultValue=None))
        self.addParameter(QgsProcessingParameterFile('E', 'Daily data of evapotranspiration', defaultValue=None))
        self.addParameter(QgsProcessingParameterFolderDestination('Output_Folder','Folder for dowload maps'))
        self.addParameter(QgsProcessingParameterMultipleLayers('P','Daily data of rain', defaultValue=None))
  
    
    def processAlgorithm(self, parameters, context, model_feedback):
        
        feedback = QgsProcessingMultiStepFeedback(1, model_feedback)
        results = {}
        outputs = {}
        
        folder = QgsProcessingUtils.tempFolder()
        folder = folder.replace('/','\\')
        
        CN = self.parameterAsLayer(parameters, 'CN', context)
        DTM = self.parameterAsLayer(parameters, 'DTM', context)
        ks_scarico = self.parameterAsLayer(parameters, 'ks_scarico', context)
        ks_carico = self.parameterAsLayer(parameters, 'ks_carico', context)
        bedrock = self.parameterAsLayer(parameters, 'bedrock', context)
        falda = self.parameterAsLayer(parameters, 'falda', context)
        E = pd.read_csv(parameters['E'],';')
        n_eff = self.parameterAsLayer(parameters, 'neff', context)
        P = self.parameterAsLayerList(parameters,'P',context)
        


        if len(P)==1 and P[0].source()[-3:]=='csv':
            P = pd.read_csv(P[0].source(),';')


        
        
            alg_params = {
                'a' : CN,
                'expression' : 'round((A*4.2)/(10-0.058*A))',
                'output' : folder+'\\CN_I.tif'
            }
            
            outputs['CN_I'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['CN_I'] = outputs['CN_I']['output']
            
            alg_params = {
                'a' : CN,
                'expression' : 'round((A*23)/(10+0.13*A))',
                'output' : folder+'\\CN_III.tif'
            }
            
            outputs['CN_III'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['CN_III'] = outputs['CN_III']['output']
    
            
            alg_params = {
                'a' : CN,
                'expression' : 'round((1000.00/A-10)*25.4)',
                'output' : folder+'\\S_II.tif'
            }
            
            outputs['S_II'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['S_II'] = outputs['S_II']['output']
            
            alg_params = {
                'a' : outputs['CN_I']['output'],
                'expression' : 'round((1000.00/A-10)*25.4)',
                'output' : folder+'\\S_I.tif'
            }
            
            outputs['S_I'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['S_I'] = outputs['S_I']['output']
            
            alg_params = {
                'a' : outputs['CN_III']['output'],
                'expression' : 'round((1000.00/A-10)*25.4)',
                'output' : folder+'\\S_III.tif'
            }
            
            outputs['S_III'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['S_III'] = outputs['S_III']['output']
            
    
    
            
            alg_params = { 
                '-a' : True, 
                '-e' : False, 
                '-n' : False, 
                'GRASS_RASTER_FORMAT_META' : '', 
                'GRASS_RASTER_FORMAT_OPT' : '', 
                'GRASS_REGION_CELLSIZE_PARAMETER' : 0, 
                'GRASS_REGION_PARAMETER' : None, 
                'aspect' : 'TEMPORARY_OUTPUT', 
                'dx' : 'TEMPORARY_OUTPUT', 
                'dxx' : 'TEMPORARY_OUTPUT', 
                'dxy' : 'TEMPORARY_OUTPUT', 
                'dy' : 'TEMPORARY_OUTPUT', 
                'dyy' : 'TEMPORARY_OUTPUT', 
                'elevation' : DTM, 
                'format' : 0, 
                'min_slope' : 0, 
                'pcurvature' : 'TEMPORARY_OUTPUT', 
                'precision' : 0, 
                'slope' :  folder+'\\slope.tif', 
                'tcurvature' : 'TEMPORARY_OUTPUT', 
                'zscale' : 1
            }
            
            outputs['slope'] = processing.run('grass7:r.slope.aspect', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['slope'] = outputs['slope']['slope']
            
            
            alg_params = {
                'a' : outputs['slope']['slope'],
                'expression' : 'if(tan(A)<0.01,0.01,tan(A))',
                'output' : folder+'\\tan_b.tif', 
            }
            
            outputs['tan_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['tan_b'] = outputs['tan_b']['output']
    
            alg_params = {
                'a' : outputs['slope']['slope'],
                'expression' : 'if(sin(A)<0.01,0.01,sin(A))',
                'output' : folder+'\\sin_b.tif' 
            }
            
            outputs['sin_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['sin_b'] = outputs['sin_b']['output']
            
            alg_params = {
                'a' : outputs['slope']['slope'],
                'expression' : 'cos(A)',
                'output' : folder+'\\cos_b.tif', 
            }
            
            outputs['cos_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['cos_b'] = outputs['cos_b']['output']
    
            
            alg_params = {
                'a' : ks_carico,
                'b' : outputs['tan_b']['output'],
                'expression' : '(A* B* 86400) / 5',
                'output' : folder+'\\lambda_1.tif', 
            }
            
            outputs['lambda_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['lambda_1'] = outputs['lambda_1']['output']
            
            alg_params = {
                'a' : ks_scarico,
                'b' : outputs['tan_b']['output'],
                'expression' : '(A* B* 86400) / 5',
                'output' : folder+'\\lambda_2.tif', 
            }
            
            outputs['lambda_2'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['lambda_2'] = outputs['lambda_2']['output']
            
            
            
            alg_params = {
                'a' : bedrock,
                'b' : falda,
                'expression' : 'B-A',
                'output' : folder+'\\diff_f_b.tif', 
            }
            
            outputs['diff_f_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['diff_f_b'] = outputs['diff_f_b']['output'] 
            
            alg_params = {
                'a' : DTM,
                'b' : bedrock,
                'expression' : 'A-B',
                'output' : folder+'\\diff_d_b.tif', 
            }
            
            outputs['diff_d_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['diff_d_b'] = outputs['diff_d_b']['output']
            
    
            
            
            alg_params = {
                'a' : outputs['tan_b']['output'],
                'expression' : str(parameters['tan_phi'])+'/A',
                'output' : folder+'\\Fs_nw.tif'
            }
            
            outputs['Fs_nw'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_nw'] = outputs['Fs_nw']['output']  
            
            
            alg_params = {
                'a' : outputs['diff_f_b']['output'],
                'b' : outputs['lambda_1']['output'],
                'expression' : 'A*1000*(1-exp(-(B)))',
                'output' : folder+'\\D_iniziale.tif'
            }
            
            outputs['D_iniziale'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['D_iniziale'] = outputs['D_iniziale']['output']
            
    
            
            alg_params = {
                'a' : outputs['diff_f_b']['output'],
                'b' : outputs['diff_d_b']['output'],
                'expression' : 'A / B',
                'output' : folder+'\\m_iniziale.tif'
            }
            
            outputs['m_iniziale'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['m_iniziale'] = outputs['m_iniziale']['output']
            
    
            
            alg_params = {
                'a' : outputs['m_iniziale']['output'],
                'b' : outputs['tan_b']['output'],
                'expression' : 'if((('+ str(parameters['Gamma'])+ '- (A * 10)) / '+str(parameters['Gamma'])+')* ('+str(parameters['tan_phi'])+ '/B) < 25,(('+str(parameters['Gamma']) +'- (A * 10)) /'+ str(parameters['Gamma'])+') * (' +str(parameters['tan_phi'])+ '/ B),25)',
                'output' : folder+'\\Fs_iniziale.tif'
            }
            
            outputs['Fs_iniziale'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_iniziale'] = outputs['Fs_iniziale']['output']  
         
            
            alg_params = {
                'a' : outputs['m_iniziale']['output'],
                'b' : outputs['diff_d_b']['output'],
                'c' : outputs['cos_b']['output'],
                'd' : outputs['sin_b']['output'],
                'expression' : 'if(('+str(parameters['coes'])+' + (('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+')) / ('+str(parameters['Gamma'])+' * B* D * C) < 32, ('+str(parameters['coes'])+' + ('+str(parameters['Gamma'])+' - (A * 10)) * B* (C ^ 2) *'+ str(parameters['tan_phi'])+') / ('+str(parameters['Gamma'])+' * B* D * C), 32)',
                'output' : folder+'\\Fs_coes_iniziale.tif'
            }
            
            outputs['Fs_coes_iniziale'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_coes_iniziale'] = outputs['Fs_coes_iniziale']['output']  
            
    
            
            P_0 = P['P'][0].replace(',','.')
            E_0 = E['E'][0].replace(',','.')
            sum_P = float(P_0)
            date_0 = E['Date'][0].replace('/','-')
            
            alg_params = {
                'a' :  outputs['S_I']['output'],
                'expression' : ' if(' +P_0+ '> 0.2*A, (('+P_0+' -0.2*A)^2)/('+P_0+' +0.8*A),0)',
                'output' :folder+'\\R_0.tif'
            }
            
            outputs['R_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['R_0'] = outputs['R_0']['output']  
            
    
    
    
            alg_params = {
                'a' : outputs['R_0']['output'],
                'b' : outputs['D_iniziale']['output'],
                'c' : outputs['S_I']['output'],
                'expression' : 'if((' + P_0+' - A - B) < 0.2 * C,'+ P_0+' - A - B, (0.04 * (C)^2 + 0.8 * C * (' + P_0+' - A - B)) / (1.2 * C - (' + P_0+' - A - B)))',
                'output' : folder+'\\Pf_0.tif'
            }
            
            outputs['Pf_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Pf_0'] = outputs['Pf_0']['output']  
            
    
            
            alg_params = {
                'a' : outputs['diff_f_b']['output'],
                'b' : outputs['D_iniziale']['output'],
                'c' : outputs['R_0']['output'],
                'd' : n_eff,
                'expression' : 'A*1000 - '+ E_0+' - B + ('+P_0+' - C)/D',
                'output' : folder+'\\V_0.tif'
            }
            
            outputs['V_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['V_0'] = outputs['V_0']['output']     
            
    
            
            alg_params = {
                'a' : outputs['V_0']['output'],
                'b' : outputs['lambda_1']['output'],
                'c' : outputs['lambda_2']['output'],
                'expression' :  'if('+P_0+' > 0, A* (1 - exp(-(B))) , A* (1 - exp(-(C))))',
                'output' : folder+'\\D_0.tif'
            }
            
            outputs['D_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['D_0'] = outputs['D_0']['output']
    
                  
    
            alg_params = {
                'a' : outputs['D_0']['output'],
                'b' : outputs['D_iniziale']['output'],
                'expression' : 'A + B',
                'output' : folder+'\\Dc_0.tif'
            }
            
            outputs['Dc_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Dc_0'] = outputs['Dc_0']['output']
            
    
            
            alg_params = {
                'a' : outputs['V_0']['output'],
                'b' : outputs['diff_d_b']['output'],
                'expression' : 'if((A/1000)>B, B, A/1000)',
                'output' : parameters['Output_Folder']+'\\Hf_'+date_0+'.tif'
            }
            
            outputs['Hf_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Hf_0'] = outputs['Hf_0']['output']
    
            
            alg_params = {
                'a' : outputs['Hf_0']['output'],
                'b' : outputs['diff_d_b']['output'],
                'expression' : 'A/B',
                'output' : folder+'\\m_0.tif'
            }
            
            outputs['m_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['m_0'] = outputs['m_0']['output']  
            
    
    
            alg_params = {
                'a' : outputs['m_0']['output'],
                'b' : outputs['tan_b']['output'],
                'expression' : 'if((('+ str(parameters['Gamma'])+ '- (A * 10)) / '+str(parameters['Gamma'])+')* ('+str(parameters['tan_phi'])+ '/B) < 25,(('+str(parameters['Gamma']) +'- (A * 10)) /'+ str(parameters['Gamma'])+') * (' +str(parameters['tan_phi'])+ '/ B),25)',
                'output' : parameters['Output_Folder']+'\\FS_'+date_0+'.tif'
            }
            
            outputs['Fs_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_0'] = outputs['Fs_0']['output']  
         
            
            alg_params = {
                'a' : outputs['m_0']['output'],
                'b' : outputs['diff_d_b']['output'],
                'c' : outputs['cos_b']['output'],
                'd' : outputs['sin_b']['output'],
                'expression' : 'if(('+str(parameters['coes'])+' + (('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+')) / ('+str(parameters['Gamma'])+' * B* D * C) < 32, ('+str(parameters['coes'])+' + ('+str(parameters['Gamma'])+' - (A * 10)) * B* (C ^ 2) *'+ str(parameters['tan_phi'])+') / ('+str(parameters['Gamma'])+' * B* D * C), 32)',
                'output' : parameters['Output_Folder']+'\\Fs_coes_'+date_0+'.tif'
            }
            
            outputs['Fs_coes_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_coes_0'] = outputs['Fs_coes_0']['output'] 
            
    
            
            alg_params = {
                'a' : outputs['Fs_0']['output']  ,
                'b' : outputs['Fs_iniziale']['output']  ,
                'expression' : 'A-B',
                'output' : folder+'\\Diff_Fs_0.tif'
            }
            
            outputs['Diff_Fs_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Diff_Fs_0'] = outputs['Diff_Fs_0']['output']         
            
            
            alg_params = {
                'a' : outputs['Fs_coes_0']['output']  ,
                'b' : outputs['Fs_coes_iniziale']['output']  ,
                'expression' : 'A-B',
                'output' :  folder+'\\Diff_Fs_coes_0.tif'
            }
            
            outputs['Diff_Fs_coes_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Diff_Fs_coes_0'] = outputs['Diff_Fs_coes_0']['output'] 
            
            P_1 = P['P'][1].replace(',','.')
            E_1 = E['E'][1].replace(',','.')
            sum_P += float(P_1)
            date_1 = E['Date'][1].replace('/','-')
            
            alg_params = {
                'a' : outputs['S_I']['output'],
                'b' : outputs['S_II']['output'],
                'c' : outputs['S_III']['output'],
                'expression' : 'if('+P_1 +'+'+ P_0+' < 5, A,if(('+P_1+'+'+ P_0+')>100,C,B))',
                'output' : folder+'\\S_1.tif'
            }
            
            outputs['S_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['S_1'] = outputs['S_1']['output'] 
            
    
            
            
            alg_params = {
                'a' : outputs['Pf_0']['output'] ,
                'expression' : P_1 +'+A',
                'output' : folder+'\\Pc_1.tif'
            }
            
            outputs['Pc_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Pc_1'] = outputs['Pc_1']['output']             
            
    
            
            alg_params = {
                'a' : outputs['Pc_1']['output'],
                'b' : outputs['S_1']['output'],
                'expression' : 'if(A > 0.2*B, ((A -0.2*B )^2)/(A + 0.8*B),0)',
                'output' : folder+"\\Rc_1.tif"
            }
            
            outputs['Rc_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Rc_1'] = outputs['Rc_1']['output']             
            
    
            
            
            alg_params = {
                'a' : outputs['Pc_1']['output'],
                'b' : outputs['Rc_1']['output'],
                'c' : outputs['D_0']['output'],
                'd' : outputs['S_1']['output'],
                'expression' : 'if((A - B - C) < 0.2 * D, A - B - C, (0.04 * (D^2 + 0.8 * D * (A - B - C)) / (1.2 * D - (A - B - C))))',
                'output' : folder+'\\Pfc_1.tif'
            }
            
            outputs['Pfc_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Pfc_1'] = outputs['Pfc_1']['output']             
            
            
            alg_params = {
                'a' : outputs['diff_f_b']['output'],
                'b' : outputs['D_0']['output'],
                'c' : outputs['Pc_1']['output'],
                'd' : outputs['Rc_1']['output'],
                'e' : outputs['D_iniziale']['output'],
                'f' : n_eff,
                'expression' : 'A*1000 -'+ E_1+' -B + (C - D + E)/F',
                'output' : folder+'\\V_1.tif'
            }
            
            outputs['V_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['V_1'] = outputs['V_1']['output']             
            
    
            
            alg_params = {
                'a' : outputs['V_1']['output'],
                'b' : outputs['lambda_1']['output'],
                'c' : outputs['lambda_2']['output'],
                'expression' : 'if('+P_1+' > 0, A* (1 - exp(-(B))) , A* (1 - exp(-(C))))',
                'output' : folder+'\\D_1.tif'
            }
            
            outputs['D_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['D_1'] = outputs['D_1']['output']             
            
    
            
            alg_params = {
                'a' : outputs['Dc_0']['output'],
                'b' : outputs['D_1']['output'],
                'expression' : 'A+B',
                'output' : folder + '\\Dc_1.tif'
            }
            
            outputs['Dc_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Dc_1'] = outputs['Dc_1']['output']             
            
    
                    
            alg_params = {
                'a' : outputs['V_1']['output'],
                'b' : outputs['diff_d_b']['output'],
                'expression' : 'if((A/1000)>B, B, A/1000)',
                'output' : parameters['Output_Folder']+'\\Hf_'+date_1+'.tif'
            }
            
            outputs['Hf_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Hf_1'] = outputs['Hf_1']['output']
            
    
            
            
            alg_params = {
                'a' :  outputs['Hf_1']['output'],
                'b' :  outputs['diff_d_b']['output'],
                'expression' : 'A/B',
                'output' : folder + '\\m_1.tif'
            }
            
            outputs['m_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['m_1'] = outputs['m_1']['output']  
            
    
    
    
            alg_params = {
                'a' : outputs['m_1']['output'],
                'b' : outputs['tan_b']['output'],
                'expression' : 'if((('+ str(parameters['Gamma'])+ '- (A * 10)) / '+str(parameters['Gamma'])+')* ('+str(parameters['tan_phi'])+ '/B) < 25,(('+str(parameters['Gamma']) +'- (A * 10)) /'+ str(parameters['Gamma'])+') * (' +str(parameters['tan_phi'])+ '/ B),25)',
                'output' : parameters['Output_Folder']+'\\FS_'+date_1+'.tif'
            }
            
            outputs['Fs_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_1'] = outputs['Fs_1']['output']  
         
            
            alg_params = {
                'a' : outputs['m_1']['output'],
                'b' : outputs['diff_d_b']['output'],
                'c' : outputs['cos_b']['output'],
                'd' : outputs['sin_b']['output'],
                'expression' : 'if(('+str(parameters['coes'])+' + (('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+')) / ('+str(parameters['Gamma'])+' * B* D * C) < 32, ('+str(parameters['coes'])+' + ('+str(parameters['Gamma'])+' - (A * 10)) * B* (C ^ 2) *'+ str(parameters['tan_phi'])+') / ('+str(parameters['Gamma'])+' * B* D * C), 32)',
                'output' : parameters['Output_Folder']+'\\Fs_coes_'+date_1+'.tif'
            }
            
            outputs['Fs_coes_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_coes_1'] = outputs['Fs_coes_1']['output'] 
    
            
            alg_params = {
                'a' : outputs['Fs_1']['output'],
                'b' : outputs['Fs_iniziale']['output'],
                'expression' : 'A-B',
                'output' : folder + '\\Diff_Fs_1.tif'
            }
            
            outputs['Diff_Fs_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Diff_Fs_1'] = outputs['Diff_Fs_1']['output']         
            
            
            alg_params = {
                'a' : outputs['Fs_coes_1']['output'],
                'b' : outputs['Fs_coes_iniziale']['output'],
                'expression' : 'A-B',
                'output' : folder + '\\Diff_Fs_coes_1.tif'
            }
            
            outputs['Diff_Fs_coes_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Diff_Fs_coes_1'] = outputs['Diff_Fs_coes_1']['output'] 
    
    
            for i in range(len(E['Date'])-2):
                P_2 = P['P'][i+2].replace(',','.')
                E_2 = E['E'][i+2].replace(',','.')
                if i<3:
                    sum_P += float(P_2)
                else: 
                    sum_P = sum_P + float(P_2) - float(P['P'][i-3].replace(',','.'))
                date_2 = E['Date'][i+2].replace('/','-')
                
                
                alg_params = {
                    'a' : outputs['S_I']['output'],
                    'b' : outputs['S_II']['output'],
                    'c' : outputs['S_III']['output'],
                    'expression' : 'if('+ str(sum_P)+ ' < 5, A, if(' + str(sum_P)+ ' > 100, C, B))',
                    'output' : folder + '\\S_'+str(i+2)+'.tif'
                }
                
                outputs['S_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['S_'+str(i+2)] = outputs['S_'+str(i+2)]['output']            
    
    
    
                alg_params = {
                    'a' : outputs['Pfc_'+str(i+1)]['output'],
                    'expression' : P_2 + '+ A',
                    'output' : folder + '\\Pc_'+str(i+2)+'.tif'
                }
                
                outputs['Pc_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Pc_'+str(i+2)] = outputs['Pc_'+str(i+2)]['output']            
                
    
                
                alg_params = {
                    'a' : outputs['Pc_'+str(i+2)]['output'],
                    'b' : outputs['S_'+str(i+2)]['output'],
                    'expression' : ' if(A > 0.2*B, ((A - 0.2*B)^2)/(A + 0.8*B),0)',
                    'output' : folder + '\\Rc_'+str(i+2)+'.tif'
                }
                
                outputs['Rc_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Rc_'+str(i+2)] = outputs['Rc_'+str(i+2)]['output']            
                
    
    
                alg_params = {
                    'a' : outputs['Pc_'+str(i+2)]['output'],
                    'b' : outputs['Rc_'+str(i+2)]['output'],
                    'c': outputs['D_'+str(i+1)]['output'],
                    'd' : outputs['S_'+str(i+2)]['output'],
                    'expression' : 'if((A - B - C) < 0.2*D, (A - B - C), (0.04*(D)^2 + 0.8*D*(A - B - C)) / (1.2*D - (A - B - C)))',
                    'output' : folder + '\\Pfc_'+str(i+2)+'.tif'
                }
                
                outputs['Pfc_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Pfc_'+str(i+2)] = outputs['Pfc_'+str(i+2)]['output']            
                
    
                
                alg_params = {
                    'a' : outputs['diff_f_b']['output'],
                    'b' : outputs['D_'+str(i+1)]['output'],
                    'c': outputs['Pc_'+str(i+2)]['output'],
                    'd' : outputs['Rc_'+str(i+2)]['output'],
                    'e' : outputs['Dc_'+str(i)]['output'],
                    'f' : n_eff,
                    'expression' : 'A*1000 - '+ E_2 +' - B + (C - D + E)/F',
                    'output' : folder + '\\V_'+str(i+2)+'.tif'
                }
                
                outputs['V_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['V_'+str(i+2)] = outputs['V_'+str(i+2)]['output']            
                
    
                
                alg_params = {
                    'a' : outputs['V_'+str(i+2)]['output'],
                    'b' : outputs['lambda_1']['output'],
                    'c': outputs['lambda_2']['output'],
                    'expression' : 'if(' +P_2+' > 0, A* (1 - exp(-(B))) , A* (1 - exp(-(C))))',
                    'output' : folder + '\\D_'+str(i+2)+'.tif'
                }
                
                outputs['D_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['D_'+str(i+2)] = outputs['D_'+str(i+2)]['output']            
                
    
                
                alg_params = {
                    'a' : outputs['Dc_'+str(i+1)]['output'],
                    'b' : outputs['D_'+str(i+2)]['output'],
                    'expression' : 'A+B',
                    'output' : folder + '\\Dc_'+str(i+2)+'.tif'
                }
                
                outputs['Dc_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Dc_'+str(i+2)] = outputs['Dc_'+str(i+2)]['output']            
                
        
                
                alg_params = {
                    'a' :  outputs['V_'+str(i+2)]['output'],
                    'b' :  outputs['diff_d_b']['output'],
                    'expression' : 'if((A/1000) > B, B, A/1000)',
                    'output' : parameters['Output_Folder']+'\\Hf_'+date_2+'.tif'
                }
                
                outputs['Hf_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Hf_'+str(i+2)] = outputs['Hf_'+str(i+2)]['output']            
                
    
                alg_params = {
                    'a' : outputs['Hf_'+str(i+2)]['output'],
                    'b' : outputs['diff_d_b']['output'],
                    'expression' : 'A/B',
                    'output' : folder + '\\m_'+str(i+2)+'.tif'
                }
                
                outputs['m_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['m_'+str(i+2)] = outputs['m_'+str(i+2)]['output']  
                
        
        
                alg_params = {
                    'a' : outputs['m_'+str(i+2)]['output'],
                    'b' : outputs['tan_b']['output'],
                    'expression' : 'if((('+ str(parameters['Gamma'])+ '- (A * 10)) / '+str(parameters['Gamma'])+')* ('+str(parameters['tan_phi'])+ '/B) < 25,(('+str(parameters['Gamma']) +'- (A * 10)) /'+ str(parameters['Gamma'])+') * (' +str(parameters['tan_phi'])+ '/ B),25)',
                    'output' : parameters['Output_Folder']+'\\FS_'+date_2+'.tif'
                }
                
                outputs['Fs_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Fs_'+str(i+2)] = outputs['Fs_'+str(i+2)]['output']  
             
                
                alg_params = {
                    'a' : outputs['m_'+str(i+2)]['output'],
                    'b' : outputs['diff_d_b']['output'],
                    'c' : outputs['cos_b']['output'],
                    'd' : outputs['sin_b']['output'],
                    'expression' : 'if(('+str(parameters['coes'])+' + (('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+')) / ('+str(parameters['Gamma'])+' * B * D * C) < 32, ('+str(parameters['coes'])+' + ('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+') / ('+str(parameters['Gamma'])+' * B * D * C), 32)',
                    'output' : parameters['Output_Folder']+'\\FS_coes_'+date_2+'.tif'
                }
                
                outputs['Fs_coes_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Fs_coes_'+str(i+2)] = outputs['Fs_coes_'+str(i+2)]['output'] 
                
                
                alg_params = {
                    'a' : outputs['Fs_'+str(i+2)]['output'],
                    'b' : outputs['Fs_iniziale']['output'],
                    'expression' : 'A-B',
                    'output' : folder + '\\Diff_Fs_'+str(i+2)+'.tif'
                }
                
                outputs['Diff_Fs_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Diff_Fs_'+str(i+2)] = outputs['Diff_Fs_'+str(i+2)]['output']         
                
                
                alg_params = {
                    'a' : outputs['Fs_coes_'+str(i+2)]['output'],
                    'b' : outputs['Fs_coes_iniziale']['output'],
                    'expression' : 'A - B',
                    'output' : folder + '\\Diff_Fs_coes'+str(i+2)+'.tif'
                }
                
                outputs['Diff_Fs_coes_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Diff_Fs_coes_'+str(i+2)] = outputs['Diff_Fs_coes_'+str(i+2)]['output'] 
                
                
    
        else:
            E = pd.read_csv(parameters['E'],';')
            P_no_ordered = self.parameterAsLayerList(parameters,'P',context)
            P = []
            for date in E['Date']:
                for p in P_no_ordered:
                    if date.replace('/','') == p.source()[-16:-8]:
                        P.append(p)
        

        
        
            alg_params = {
                'a' : CN,
                'expression' : 'round((A*4.2)/(10-0.058*A))',
                'output' : folder+'\\CN_I.tif'
            }
            
            outputs['CN_I'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['CN_I'] = outputs['CN_I']['output']
            
            alg_params = {
                'a' : CN,
                'expression' : 'round((A*23)/(10+0.13*A))',
                'output' : folder+'\\CN_III.tif'
            }
            
            outputs['CN_III'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['CN_III'] = outputs['CN_III']['output']
    
            
            alg_params = {
                'a' : CN,
                'expression' : 'round((1000.00/A-10)*25.4)',
                'output' : folder+'\\S_II.tif'
            }
            
            outputs['S_II'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['S_II'] = outputs['S_II']['output']
            
            alg_params = {
                'a' : outputs['CN_I']['output'],
                'expression' : 'round((1000.00/A-10)*25.4)',
                'output' : folder+'\\S_I.tif'
            }
            
            outputs['S_I'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['S_I'] = outputs['S_I']['output']
            
            alg_params = {
                'a' : outputs['CN_III']['output'],
                'expression' : 'round((1000.00/A-10)*25.4)',
                'output' : folder+'\\S_III.tif'
            }
            
            outputs['S_III'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['S_III'] = outputs['S_III']['output']
            
    
    
            
            alg_params = { 
                '-a' : True, 
                '-e' : False, 
                '-n' : False, 
                'GRASS_RASTER_FORMAT_META' : '', 
                'GRASS_RASTER_FORMAT_OPT' : '', 
                'GRASS_REGION_CELLSIZE_PARAMETER' : 0, 
                'GRASS_REGION_PARAMETER' : None, 
                'aspect' : 'TEMPORARY_OUTPUT', 
                'dx' : 'TEMPORARY_OUTPUT', 
                'dxx' : 'TEMPORARY_OUTPUT', 
                'dxy' : 'TEMPORARY_OUTPUT', 
                'dy' : 'TEMPORARY_OUTPUT', 
                'dyy' : 'TEMPORARY_OUTPUT', 
                'elevation' : DTM, 
                'format' : 0, 
                'min_slope' : 0, 
                'pcurvature' : 'TEMPORARY_OUTPUT', 
                'precision' : 0, 
                'slope' :  folder+'\\slope.tif', 
                'tcurvature' : 'TEMPORARY_OUTPUT', 
                'zscale' : 1
            }
            
            outputs['slope'] = processing.run('grass7:r.slope.aspect', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['slope'] = outputs['slope']['slope']
            
            
            alg_params = {
                'a' : outputs['slope']['slope'],
                'expression' : 'if(tan(A)<0.01,0.01,tan(A))',
                'output' : folder+'\\tan_b.tif', 
            }
            
            outputs['tan_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['tan_b'] = outputs['tan_b']['output']
    
            alg_params = {
                'a' : outputs['slope']['slope'],
                'expression' : 'if(sin(A)<0.01,0.01,sin(A))',
                'output' : folder+'\\sin_b.tif' 
            }
            
            outputs['sin_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['sin_b'] = outputs['sin_b']['output']
            
            alg_params = {
                'a' : outputs['slope']['slope'],
                'expression' : 'cos(A)',
                'output' : folder+'\\cos_b.tif', 
            }
            
            outputs['cos_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['cos_b'] = outputs['cos_b']['output']
    
            
            alg_params = {
                'a' : ks_carico,
                'b' : outputs['tan_b']['output'],
                'expression' : '(A* B* 86400) / 5',
                'output' : folder+'\\lambda_1.tif', 
            }
            
            outputs['lambda_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['lambda_1'] = outputs['lambda_1']['output']
            
            alg_params = {
                'a' : ks_scarico,
                'b' : outputs['tan_b']['output'],
                'expression' : '(A* B* 86400) / 5',
                'output' : folder+'\\lambda_2.tif', 
            }
            
            outputs['lambda_2'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['lambda_2'] = outputs['lambda_2']['output']
            
            
            
            alg_params = {
                'a' : bedrock,
                'b' : falda,
                'expression' : 'B-A',
                'output' : folder+'\\diff_f_b.tif', 
            }
            
            outputs['diff_f_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['diff_f_b'] = outputs['diff_f_b']['output'] 
            
            alg_params = {
                'a' : DTM,
                'b' : bedrock,
                'expression' : 'A-B',
                'output' : folder+'\\diff_d_b.tif', 
            }
            
            outputs['diff_d_b'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['diff_d_b'] = outputs['diff_d_b']['output']
            
    
            
            
            alg_params = {
                'a' : outputs['tan_b']['output'],
                'expression' : str(parameters['tan_phi'])+'/A',
                'output' : folder+'\\Fs_nw.tif'
            }
            
            outputs['Fs_nw'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_nw'] = outputs['Fs_nw']['output']  
            
            
            alg_params = {
                'a' : outputs['diff_f_b']['output'],
                'b' : outputs['lambda_1']['output'],
                'expression' : 'A*1000*(1-exp(-(B)))',
                'output' : folder+'\\D_iniziale.tif'
            }
            
            outputs['D_iniziale'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['D_iniziale'] = outputs['D_iniziale']['output']
            
    
            
            alg_params = {
                'a' : outputs['diff_f_b']['output'],
                'b' : outputs['diff_d_b']['output'],
                'expression' : 'A / B',
                'output' : folder+'\\m_iniziale.tif'
            }
            
            outputs['m_iniziale'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['m_iniziale'] = outputs['m_iniziale']['output']
            
    
            
            alg_params = {
                'a' : outputs['m_iniziale']['output'],
                'b' : outputs['tan_b']['output'],
                'expression' : 'if((('+ str(parameters['Gamma'])+ '- (A * 10)) / '+str(parameters['Gamma'])+')* ('+str(parameters['tan_phi'])+ '/B) < 25,(('+str(parameters['Gamma']) +'- (A * 10)) /'+ str(parameters['Gamma'])+') * (' +str(parameters['tan_phi'])+ '/ B),25)',
                'output' : folder+'\\Fs_iniziale.tif'
            }
            
            outputs['Fs_iniziale'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_iniziale'] = outputs['Fs_iniziale']['output']  
         
            
            alg_params = {
                'a' : outputs['m_iniziale']['output'],
                'b' : outputs['diff_d_b']['output'],
                'c' : outputs['cos_b']['output'],
                'd' : outputs['sin_b']['output'],
                'expression' : 'if(('+str(parameters['coes'])+' + (('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+')) / ('+str(parameters['Gamma'])+' * B* D * C) < 32, ('+str(parameters['coes'])+' + ('+str(parameters['Gamma'])+' - (A * 10)) * B* (C ^ 2) *'+ str(parameters['tan_phi'])+') / ('+str(parameters['Gamma'])+' * B* D * C), 32)',
                'output' : folder+'\\Fs_coes_iniziale.tif'
            }
            
            outputs['Fs_coes_iniziale'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_coes_iniziale'] = outputs['Fs_coes_iniziale']['output']  
            
    
            
            P_0 = P[0].source()
            E_0 = E['E'][0].replace(',','.')
            date_0 = E['Date'][0].replace('/','-')
            
            alg_params = {
                'a' :  outputs['S_I']['output'],
                'b' : P_0,
                'expression' : ' if(B> 0.2*A, ((B -0.2*A)^2)/(B +0.8*A),0)',
                'output' :folder+'\\R_0.tif'
            }
            
            outputs['R_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['R_0'] = outputs['R_0']['output']  
            
    
    
    
            alg_params = {
                'a' : outputs['R_0']['output'],
                'b' : outputs['D_iniziale']['output'],
                'c' : outputs['S_I']['output'],
                'd' : P_0,
                'expression' : 'if((D - A - B) < 0.2 * C,D - A - B, (0.04 * (C)^2 + 0.8 * C * (D - A - B)) / (1.2 * C - (D - A - B)))',
                'output' : folder+'\\Pf_0.tif'
            }
            
            outputs['Pf_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Pf_0'] = outputs['Pf_0']['output']  
            
    
            
            alg_params = {
                'a' : outputs['diff_f_b']['output'],
                'b' : outputs['D_iniziale']['output'],
                'c' : outputs['R_0']['output'],
                'd' : n_eff,
                'e' : P_0,
                'expression' : 'A*1000 - '+ E_0+' - B + (E - C)/D',
                'output' : folder+'\\V_0.tif'
            }
            
            outputs['V_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['V_0'] = outputs['V_0']['output']     
            
    
            
            alg_params = {
                'a' : outputs['V_0']['output'],
                'b' : outputs['lambda_1']['output'],
                'c' : outputs['lambda_2']['output'],
                'd' : P_0,
                'expression' :  'if(D > 0, A* (1 - exp(-(B))) , A* (1 - exp(-(C))))',
                'output' : folder+'\\D_0.tif'
            }
            
            outputs['D_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['D_0'] = outputs['D_0']['output']
    
                  
    
            alg_params = {
                'a' : outputs['D_0']['output'],
                'b' : outputs['D_iniziale']['output'],
                'expression' : 'A + B',
                'output' : folder+'\\Dc_0.tif'
            }
            
            outputs['Dc_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Dc_0'] = outputs['Dc_0']['output']
            
    
            
            alg_params = {
                'a' : outputs['V_0']['output'],
                'b' : outputs['diff_d_b']['output'],
                'expression' : 'if((A/1000)>B, B, A/1000)',
                'output' : parameters['Output_Folder']+'\\Hf_'+date_0+'.tif'
            }
            
            outputs['Hf_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Hf_0'] = outputs['Hf_0']['output']
    
            
            alg_params = {
                'a' : outputs['Hf_0']['output'],
                'b' : outputs['diff_d_b']['output'],
                'expression' : 'A/B',
                'output' : folder+'\\m_0.tif'
            }
            
            outputs['m_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['m_0'] = outputs['m_0']['output']  
            
    
    
            alg_params = {
                'a' : outputs['m_0']['output'],
                'b' : outputs['tan_b']['output'],
                'expression' : 'if((('+ str(parameters['Gamma'])+ '- (A * 10)) / '+str(parameters['Gamma'])+')* ('+str(parameters['tan_phi'])+ '/B) < 25,(('+str(parameters['Gamma']) +'- (A * 10)) /'+ str(parameters['Gamma'])+') * (' +str(parameters['tan_phi'])+ '/ B),25)',
                'output' : parameters['Output_Folder']+'\\FS_'+date_0+'.tif'
            }
            
            outputs['Fs_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_0'] = outputs['Fs_0']['output']  
         
            
            alg_params = {
                'a' : outputs['m_0']['output'],
                'b' : outputs['diff_d_b']['output'],
                'c' : outputs['cos_b']['output'],
                'd' : outputs['sin_b']['output'],
                'expression' : 'if(('+str(parameters['coes'])+' + (('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+')) / ('+str(parameters['Gamma'])+' * B* D * C) < 32, ('+str(parameters['coes'])+' + ('+str(parameters['Gamma'])+' - (A * 10)) * B* (C ^ 2) *'+ str(parameters['tan_phi'])+') / ('+str(parameters['Gamma'])+' * B* D * C), 32)',
                'output' : parameters['Output_Folder']+'\\Fs_coes_'+date_0+'.tif'
            }
            
            outputs['Fs_coes_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_coes_0'] = outputs['Fs_coes_0']['output'] 
            
    
            
            alg_params = {
                'a' : outputs['Fs_0']['output']  ,
                'b' : outputs['Fs_iniziale']['output']  ,
                'expression' : 'A-B',
                'output' : folder+'\\Diff_Fs_0.tif'
            }
            
            outputs['Diff_Fs_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Diff_Fs_0'] = outputs['Diff_Fs_0']['output']         
            
            
            alg_params = {
                'a' : outputs['Fs_coes_0']['output']  ,
                'b' : outputs['Fs_coes_iniziale']['output']  ,
                'expression' : 'A-B',
                'output' :  folder+'\\Diff_Fs_coes_0.tif'
            }
            
            outputs['Diff_Fs_coes_0'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Diff_Fs_coes_0'] = outputs['Diff_Fs_coes_0']['output'] 
            
            P_1 = P[1].source()
            E_1 = E['E'][1].replace(',','.')
            date_1 = E['Date'][1].replace('/','-')
            
            alg_params = {
                'a' : P_0,
                'b' : P_1,
                'expression' : 'A+B',
                'output': folder+'\\sum_P_1.tif'
            }
            
            outputs['sum_P_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)

            
            alg_params = {
                'a' : outputs['S_I']['output'],
                'b' : outputs['S_II']['output'],
                'c' : outputs['S_III']['output'],
                'd' : outputs['sum_P_1']['output'],
                'expression' : 'if(D< 5, A,if(D>100,C,B))',
                'output' : folder+'\\S_1.tif'
            }
            
            outputs['S_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['S_1'] = outputs['S_1']['output'] 
            
    
            
            
            alg_params = {
                'a' : outputs['Pf_0']['output'] ,
                'b' : P_1,
                'expression' : 'B+A',
                'output' : folder+'\\Pc_1.tif'
            }
            
            outputs['Pc_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Pc_1'] = outputs['Pc_1']['output']             
            
    
            
            alg_params = {
                'a' : outputs['Pc_1']['output'],
                'b' : outputs['S_1']['output'],
                'expression' : 'if(A > 0.2*B, ((A -0.2*B )^2)/(A + 0.8*B),0)',
                'output' : folder+"\\Rc_1.tif"
            }
            
            outputs['Rc_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Rc_1'] = outputs['Rc_1']['output']             
            
    
            
            
            alg_params = {
                'a' : outputs['Pc_1']['output'],
                'b' : outputs['Rc_1']['output'],
                'c' : outputs['D_0']['output'],
                'd' : outputs['S_1']['output'],
                'expression' : 'if((A - B - C) < 0.2 * D, A - B - C, (0.04 * (D^2 + 0.8 * D * (A - B - C)) / (1.2 * D - (A - B - C))))',
                'output' : folder+'\\Pfc_1.tif'
            }
            
            outputs['Pfc_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Pfc_1'] = outputs['Pfc_1']['output']             
            
            
            alg_params = {
                'a' : outputs['diff_f_b']['output'],
                'b' : outputs['D_0']['output'],
                'c' : outputs['Pc_1']['output'],
                'd' : outputs['Rc_1']['output'],
                'e' : outputs['D_iniziale']['output'],
                'f' : n_eff,
                'expression' : 'A*1000 -'+ E_1+' -B + (C - D + E)/F',
                'output' : folder+'\\V_1.tif'
            }
            
            outputs['V_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['V_1'] = outputs['V_1']['output']             
            
    
            
            alg_params = {
                'a' : outputs['V_1']['output'],
                'b' : outputs['lambda_1']['output'],
                'c' : outputs['lambda_2']['output'],
                'd' : P_1,
                'expression' : 'if(D > 0, A* (1 - exp(-(B))) , A* (1 - exp(-(C))))',
                'output' : folder+'\\D_1.tif'
            }
            
            outputs['D_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['D_1'] = outputs['D_1']['output']             
            
    
            
            alg_params = {
                'a' : outputs['Dc_0']['output'],
                'b' : outputs['D_1']['output'],
                'expression' : 'A+B',
                'output' : folder + '\\Dc_1.tif'
            }
            
            outputs['Dc_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Dc_1'] = outputs['Dc_1']['output']             
            
    
                    
            alg_params = {
                'a' : outputs['V_1']['output'],
                'b' : outputs['diff_d_b']['output'],
                'expression' : 'if((A/1000)>B, B, A/1000)',
                'output' : parameters['Output_Folder']+'\\Hf_'+date_1+'.tif'
            }
            
            outputs['Hf_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Hf_1'] = outputs['Hf_1']['output']
            
    
            
            
            alg_params = {
                'a' :  outputs['Hf_1']['output'],
                'b' :  outputs['diff_d_b']['output'],
                'expression' : 'A/B',
                'output' : folder + '\\m_1.tif'
            }
            
            outputs['m_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['m_1'] = outputs['m_1']['output']  
            
    
    
    
            alg_params = {
                'a' : outputs['m_1']['output'],
                'b' : outputs['tan_b']['output'],
                'expression' : 'if((('+ str(parameters['Gamma'])+ '- (A * 10)) / '+str(parameters['Gamma'])+')* ('+str(parameters['tan_phi'])+ '/B) < 25,(('+str(parameters['Gamma']) +'- (A * 10)) /'+ str(parameters['Gamma'])+') * (' +str(parameters['tan_phi'])+ '/ B),25)',
                'output' : parameters['Output_Folder']+'\\FS_'+date_1+'.tif'
            }
            
            outputs['Fs_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_1'] = outputs['Fs_1']['output']  
         
            
            alg_params = {
                'a' : outputs['m_1']['output'],
                'b' : outputs['diff_d_b']['output'],
                'c' : outputs['cos_b']['output'],
                'd' : outputs['sin_b']['output'],
                'expression' : 'if(('+str(parameters['coes'])+' + (('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+')) / ('+str(parameters['Gamma'])+' * B* D * C) < 32, ('+str(parameters['coes'])+' + ('+str(parameters['Gamma'])+' - (A * 10)) * B* (C ^ 2) *'+ str(parameters['tan_phi'])+') / ('+str(parameters['Gamma'])+' * B* D * C), 32)',
                'output' : parameters['Output_Folder']+'\\Fs_coes_'+date_1+'.tif'
            }
            
            outputs['Fs_coes_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Fs_coes_1'] = outputs['Fs_coes_1']['output'] 
    
            
            alg_params = {
                'a' : outputs['Fs_1']['output'],
                'b' : outputs['Fs_iniziale']['output'],
                'expression' : 'A-B',
                'output' : folder + '\\Diff_Fs_1.tif'
            }
            
            outputs['Diff_Fs_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Diff_Fs_1'] = outputs['Diff_Fs_1']['output']         
            
            
            alg_params = {
                'a' : outputs['Fs_coes_1']['output'],
                'b' : outputs['Fs_coes_iniziale']['output'],
                'expression' : 'A-B',
                'output' : folder + '\\Diff_Fs_coes_1.tif'
            }
            
            outputs['Diff_Fs_coes_1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
            results['Diff_Fs_coes_1'] = outputs['Diff_Fs_coes_1']['output'] 
    
    
            for i in range(len(E['Date'])-2):
                P_2 = P[i+2].source()
                E_2 = E['E'][i+2].replace(',','.')
                date_2 = E['Date'][i+2].replace('/','-')
                
                if i<3:
                    
                    alg_params = {
                        'a' : outputs['sum_P_'+str(i+1)]['output'],
                        'b' : P_2,
                        'expression' : 'A+B',
                        'output': folder+'\\sum_P_'+str(i+2)+'.tif'
                    }
                    
                    outputs['sum_P_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                else: 
                    alg_params = {
                        'a' : outputs['sum_P_'+str(i+1)]['output'],
                        'b' : P_2,
                        'c' : P[i-3].source(),
                        'expression' : 'A+B-C',
                        'output': folder+'\\sum_P_'+str(i+2)+'.tif'
                    }
                    
                    outputs['sum_P_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                
                
                
                alg_params = {
                    'a' : outputs['S_I']['output'],
                    'b' : outputs['S_II']['output'],
                    'c' : outputs['S_III']['output'],
                    'd' : outputs['sum_P_'+str(i+2)]['output'],
                    'expression' : 'if(D < 5, A, if(D > 100, C, B))',
                    'output' : folder + '\\S_'+str(i+2)+'.tif'
                }
                
                outputs['S_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['S_'+str(i+2)] = outputs['S_'+str(i+2)]['output']            
    
    
    
                alg_params = {
                    'a' : outputs['Pfc_'+str(i+1)]['output'],
                    'b' : P_2,
                    'expression' : 'B + A',
                    'output' : folder + '\\Pc_'+str(i+2)+'.tif'
                }
                
                outputs['Pc_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Pc_'+str(i+2)] = outputs['Pc_'+str(i+2)]['output']            
                
    
                
                alg_params = {
                    'a' : outputs['Pc_'+str(i+2)]['output'],
                    'b' : outputs['S_'+str(i+2)]['output'],
                    'expression' : ' if(A > 0.2*B, ((A - 0.2*B)^2)/(A + 0.8*B),0)',
                    'output' : folder + '\\Rc_'+str(i+2)+'.tif'
                }
                
                outputs['Rc_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Rc_'+str(i+2)] = outputs['Rc_'+str(i+2)]['output']            
                
    
    
                alg_params = {
                    'a' : outputs['Pc_'+str(i+2)]['output'],
                    'b' : outputs['Rc_'+str(i+2)]['output'],
                    'c': outputs['D_'+str(i+1)]['output'],
                    'd' : outputs['S_'+str(i+2)]['output'],
                    'expression' : 'if((A - B - C) < 0.2*D, (A - B - C), (0.04*(D)^2 + 0.8*D*(A - B - C)) / (1.2*D - (A - B - C)))',
                    'output' : folder + '\\Pfc_'+str(i+2)+'.tif'
                }
                
                outputs['Pfc_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Pfc_'+str(i+2)] = outputs['Pfc_'+str(i+2)]['output']            
                
    
                
                alg_params = {
                    'a' : outputs['diff_f_b']['output'],
                    'b' : outputs['D_'+str(i+1)]['output'],
                    'c': outputs['Pc_'+str(i+2)]['output'],
                    'd' : outputs['Rc_'+str(i+2)]['output'],
                    'e' : outputs['Dc_'+str(i)]['output'],
                    'f' : n_eff,
                    'expression' : 'A*1000 - '+ E_2 +' - B + (C - D + E)/F',
                    'output' : folder + '\\V_'+str(i+2)+'.tif'
                }
                
                outputs['V_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['V_'+str(i+2)] = outputs['V_'+str(i+2)]['output']            
                
    
                
                alg_params = {
                    'a' : outputs['V_'+str(i+2)]['output'],
                    'b' : outputs['lambda_1']['output'],
                    'c': outputs['lambda_2']['output'],
                    'd' : P_2,
                    'expression' : 'if(D > 0, A* (1 - exp(-(B))) , A* (1 - exp(-(C))))',
                    'output' : folder + '\\D_'+str(i+2)+'.tif'
                }
                
                outputs['D_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['D_'+str(i+2)] = outputs['D_'+str(i+2)]['output']            
                
    
                
                alg_params = {
                    'a' : outputs['Dc_'+str(i+1)]['output'],
                    'b' : outputs['D_'+str(i+2)]['output'],
                    'expression' : 'A+B',
                    'output' : folder + '\\Dc_'+str(i+2)+'.tif'
                }
                
                outputs['Dc_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Dc_'+str(i+2)] = outputs['Dc_'+str(i+2)]['output']            
                
        
                
                alg_params = {
                    'a' :  outputs['V_'+str(i+2)]['output'],
                    'b' :  outputs['diff_d_b']['output'],
                    'expression' : 'if((A/1000) > B, B, A/1000)',
                    'output' : parameters['Output_Folder']+'\\Hf_'+date_2+'.tif'
                }
                
                outputs['Hf_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Hf_'+str(i+2)] = outputs['Hf_'+str(i+2)]['output']            
                
    
                alg_params = {
                    'a' : outputs['Hf_'+str(i+2)]['output'],
                    'b' : outputs['diff_d_b']['output'],
                    'expression' : 'A/B',
                    'output' : folder + '\\m_'+str(i+2)+'.tif'
                }
                
                outputs['m_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['m_'+str(i+2)] = outputs['m_'+str(i+2)]['output']  
                
        
        
                alg_params = {
                    'a' : outputs['m_'+str(i+2)]['output'],
                    'b' : outputs['tan_b']['output'],
                    'expression' : 'if((('+ str(parameters['Gamma'])+ '- (A * 10)) / '+str(parameters['Gamma'])+')* ('+str(parameters['tan_phi'])+ '/B) < 25,(('+str(parameters['Gamma']) +'- (A * 10)) /'+ str(parameters['Gamma'])+') * (' +str(parameters['tan_phi'])+ '/ B),25)',
                    'output' : parameters['Output_Folder']+'\\FS_'+date_2+'.tif'
                }
                
                outputs['Fs_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Fs_'+str(i+2)] = outputs['Fs_'+str(i+2)]['output']  
             
                
                alg_params = {
                    'a' : outputs['m_'+str(i+2)]['output'],
                    'b' : outputs['diff_d_b']['output'],
                    'c' : outputs['cos_b']['output'],
                    'd' : outputs['sin_b']['output'],
                    'expression' : 'if(('+str(parameters['coes'])+' + (('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+')) / ('+str(parameters['Gamma'])+' * B * D * C) < 32, ('+str(parameters['coes'])+' + ('+str(parameters['Gamma'])+' - (A * 10)) * B * (C ^ 2) *'+ str(parameters['tan_phi'])+') / ('+str(parameters['Gamma'])+' * B * D * C), 32)',
                    'output' : parameters['Output_Folder']+'\\FS_coes_'+date_2+'.tif'
                }
                
                outputs['Fs_coes_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Fs_coes_'+str(i+2)] = outputs['Fs_coes_'+str(i+2)]['output'] 
                
                
                alg_params = {
                    'a' : outputs['Fs_'+str(i+2)]['output'],
                    'b' : outputs['Fs_iniziale']['output'],
                    'expression' : 'A-B',
                    'output' : folder + '\\Diff_Fs_'+str(i+2)+'.tif'
                }
                
                outputs['Diff_Fs_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Diff_Fs_'+str(i+2)] = outputs['Diff_Fs_'+str(i+2)]['output']         
                
                
                alg_params = {
                    'a' : outputs['Fs_coes_'+str(i+2)]['output'],
                    'b' : outputs['Fs_coes_iniziale']['output'],
                    'expression' : 'A - B',
                    'output' : folder + '\\Diff_Fs_coes'+str(i+2)+'.tif'
                }
                
                outputs['Diff_Fs_coes_'+str(i+2)] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
                results['Diff_Fs_coes_'+str(i+2)] = outputs['Diff_Fs_coes_'+str(i+2)]['output'] 
                
                          
        alg_params = {
            'a' : outputs['Fs_coes_'+str(len(E['Date'])-1)]['output'],
            'b' : outputs['Fs_coes_iniziale']['output'],
            'expression' : 'if(B<=1,2,if(B>1 && A <=1,1,0))',
            'output' : parameters['Output_Folder']+'\\criterio1.tif'
        }
        
        outputs['Criterio1'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Criterio1'] = outputs['Criterio1']['output'] 
         
        alg_params = {
            'a' : outputs['Hf_'+str(len(E['Date'])-1)]['output'],
            'b' : outputs['Hf_0']['output'],
            'expression' : 'A - B',
            'output' : parameters['Output_Folder']+'\\Delta_falda.tif'
        }
        
        outputs['Delta_falda'] = processing.run("grass7:r.mapcalc.simple", alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Delta_falda'] = outputs['Delta_falda']['output']     

        
       
        return results
            
    def name(self):
        return 'IHG'

    def displayName(self):
        return 'IHG'
    
    def tr(self, string):
        return QCoreApplication.translate('Processing', string)
    
    def shortHelpString(self):
        return self.tr("The script will give you for each day the safety factor maps (with and without taking cohesion into account), a map of the height of the water table, a map of the difference between the water table before and after the rain event and a map of the unstable areas specifying whether they were already unstable before the event or not.\n\nThe input data must be designed as follows:\n\n-The input parameters DTM, CN, Bedrock, Water table, ks_charged, ks_discharged and neff are maps of the same area and of the same extent.\n\n-The effective cohesion, γ and tan(φ) are float numbers.\n\n-The daily data of rain and evapotranspiration is a .csv file with Date (named Date), Rain (named P), Evapotranspiration (named E)")


    def createInstance(self):
        return IHG()